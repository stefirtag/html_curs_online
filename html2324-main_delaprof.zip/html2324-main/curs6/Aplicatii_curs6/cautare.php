<?php
// echo "<pre>";
// print_r($_POST);//print_r($_GET);

 ?>
